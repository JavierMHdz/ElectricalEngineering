#include <iostream>
#include <map>
#include <set>
#include <algorithm>
#include "puzzle_solver.h"

using namespace std;



int PuzzleSolver::getNumExpansions()
{
  return expansions_;
}
